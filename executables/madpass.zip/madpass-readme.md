# Madpass

A simple executable to produce a secure yet human readable password that copies
to the clipboard with at least one random symbol

## Installation

Download and place madpass.exe into a preferred folder ie. C:\Apps
Drag the madpass.exe to the Win 10 Taskbar

## Usage

Click the madpass icon and wait for the message 'Password copied'

## License
[MIT](https://choosealicense.com/licenses/mit/)